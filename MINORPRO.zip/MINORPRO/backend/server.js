// ------------------------------
// 1️⃣ Import dependencies
// ------------------------------
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const fetch = require("node-fetch"); // npm install node-fetch@2
const mongoose = require("mongoose");

// ------------------------------
// 2️⃣ Initialize Express app
// ------------------------------
const app = express();
const PORT = 8000;

// ------------------------------
// 3️⃣ Middleware
// ------------------------------
app.use(cors());
app.use(bodyParser.json());

// ------------------------------
// 4️⃣ Connect to MongoDB
// ------------------------------
const MONGO_URI = "mongodb://localhost:27017/parkinsons_db"; // Adjust if needed
mongoose.connect(MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log("✅ Connected to MongoDB"))
.catch(err => console.error("❌ MongoDB connection error:", err));

// ------------------------------
// 5️⃣ Define Schemas & Models
// ------------------------------

// 🧠 Parkinson Prediction Schema
const predictionSchema = new mongoose.Schema({
    symptomText: String,
    severity: String,
    commonSymptoms: [String],
    numericFeatures: Object,
    prediction: Number,
    probability: Number,
    createdAt: { type: Date, default: Date.now }
});
const Prediction = mongoose.model("Prediction", predictionSchema);

// 💬 Contact Message Schema
const contactSchema = new mongoose.Schema({
    name: String,
    email: String,
    message: String,
    createdAt: { type: Date, default: Date.now }
});
const Contact = mongoose.model("Contact", contactSchema);

// ------------------------------
// 6️⃣ Test route
// ------------------------------
app.get("/", (req, res) => {
    res.send("✅ Node.js backend running and connected to MongoDB!");
});

// ------------------------------
// 7️⃣ POST route: Predict Parkinson's
// ------------------------------
app.post("/predict", async (req, res) => {
    const features = req.body;
    console.log("[server] Received features:", features);

    try {
        // Call Python ML API
        const response = await fetch("http://127.0.0.1:5000/predict", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(features)
        });

        const data = await response.json();

        // Save prediction to MongoDB
        const prediction = new Prediction({
            symptomText: features.symptomText,
            severity: features.severity,
            commonSymptoms: features.commonSymptoms,
            numericFeatures: features,
            prediction: data.prediction,
            probability: data.probability
        });

        await prediction.save();

        res.json(data);

    } catch (err) {
        console.error("[server] Python API error:", err);
        res.status(err.status || 500).json({
            error: err.error || "Prediction failed",
            detail: err.detail || ""
        });
    }
});

// ------------------------------
// 8️⃣ GET route: Fetch last 20 predictions
// ------------------------------
app.get("/history", async (req, res) => {
    try {
        const history = await Prediction.find().sort({ createdAt: -1 }).limit(20);
        res.json(history);
    } catch (err) {
        console.error("❌ Failed to fetch history:", err);
        res.status(500).json({ error: "Failed to fetch history" });
    }
});

// ------------------------------
// 9️⃣ POST route: Contact form submission
// ------------------------------
app.post("/contact", async (req, res) => {
    try {
        const { name, email, message } = req.body;

        if (!name || !email || !message) {
            return res.status(400).json({ error: "All fields are required" });
        }

        // Save contact message to MongoDB
        await Contact.create({ name, email, message });

        res.json({ success: true, message: "Message sent successfully!" });
    } catch (err) {
        console.error("❌ Error saving contact message:", err);
        res.status(500).json({ error: "Failed to send message" });
    }
});

// ------------------------------
// 🔟 (Optional) GET route: View all contact messages
// ------------------------------
app.get("/contact-messages", async (req, res) => {
    try {
        const messages = await Contact.find().sort({ createdAt: -1 });
        res.json(messages);
    } catch (err) {
        console.error("❌ Failed to fetch contact messages:", err);
        res.status(500).json({ error: "Failed to fetch contact messages" });
    }
});

// ------------------------------
// 1️⃣1️⃣ Start server
// ------------------------------
app.listen(PORT, () => {
    console.log(`✅ Node.js backend running at http://127.0.0.1:${PORT}`);
});
